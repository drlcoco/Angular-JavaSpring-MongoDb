package com.tutorial.crudmongoback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudMongoBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
